package br.com.nava.exemploApiRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploApiRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploApiRestApplication.class, args);
	}

}
